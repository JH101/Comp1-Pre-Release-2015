#COMP1 2015 Pre-release

##Introduction
The program this year is based around a game called **Capture the Sarrum**, which is a variant of **Chess**. You will have to understand both **lists** and **records** and be able to **save** to and **read** from **files** in order to complete many of the tasks.

##Your exam
In the COMP1 exam you will be asked questions about the pre-release program you have been provided with an you will also be asked to modify and improve its functionality.

This series of tasks will help you to prepare.

##Task Sheets
Each task sheet below **builds** on the previous one. You **must complete** all of the tasks in each sheet before moving on to the next sheet.

- [Task Sheet 1 - Validation Improvements](COMP1_2015_Task1.md)